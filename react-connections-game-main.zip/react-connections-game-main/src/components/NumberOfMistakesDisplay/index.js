export * from "./NumberOfMistakesDisplay";
export { default } from "./NumberOfMistakesDisplay";
