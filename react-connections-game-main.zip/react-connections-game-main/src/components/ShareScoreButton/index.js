export * from './ShareScoreButton';
export { default } from './ShareScoreButton';
