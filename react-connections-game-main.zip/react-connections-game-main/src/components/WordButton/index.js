export * from './WordButton';
export { default } from './WordButton';
